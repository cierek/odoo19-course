from odoo import models, fields, api

class CierBike(models.Model):
    _name = 'cier.bike'
    _description = 'CierTech Bike'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Bike Name', required=True, tracking=True)
    frame_no = fields.Char(string='Frame No.', tracking=True)
    purchase_date = fields.Date(string='Purchase Date')
    warranty_months = fields.Integer(string='Warranty (months)', default=24)
    warranty_end = fields.Date(string='Warranty Ends On', compute='_compute_warranty_end', store=True)

    @api.depends('purchase_date', 'warranty_months')
    def _compute_warranty_end(self):
        for rec in self:
            if rec.purchase_date and rec.warranty_months:
                rec.warranty_end = fields.Date.add(rec.purchase_date, months=rec.warranty_months)
            else:
                rec.warranty_end = False