Odoo 19 Starter (Windows/macOS/Linux)

Quick start (Windows PowerShell):
1) Extract this folder to: C:\OdooCourse\odoo19_starter  (recommended)
2) cd C:\OdooCourse\odoo19_starter
3) docker compose up -d
4) Open http://localhost:8069 and create DB:
   - DB name: test
   - Email: admin@test.com
   - Password: admin
5) In Apps: click "Update Apps List", search "CierTech Bikes", install.

Notes:
- Your custom addons are in .\addons (mounted to /mnt/extra-addons)
- Postgres creds: user=odoo, password=odoo, host=db, port=5432
- To stop: docker compose down
- To see logs: docker compose logs -f odoo