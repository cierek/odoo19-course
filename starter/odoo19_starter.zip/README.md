# Odoo 19 Starter (Windows)

## Quick Start
1. Install Docker Desktop for Windows (WSL2 backend).
2. Extract this ZIP to e.g. `C:\OdooCourse\odoo19_starter` or Desktop.
3. Double-click `start_odoo19.bat`.
4. Open http://localhost:8069 and create a database.
5. In Odoo: Developer Mode → Apps → **Update Apps List** → remove filter "Apps" → search **CierTech Bikes** → Install.

## Useful
- Start: `start_odoo19.bat` (or `docker compose up -d`)
- Stop: `stop_odoo19.bat` (or `docker compose down`)
- Reset DB: `reset_db.bat` (removes Docker volume `odoo19_starter_data` and starts fresh)
