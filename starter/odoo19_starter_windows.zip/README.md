# Odoo 19 Starter (Windows)

## Quick Start
1. Install Docker Desktop.
2. Extract this ZIP somewhere simple (e.g. `C:\\OdooCourse\\odoo19_starter` on Windows or `~/OdooCourse/odoo19_starter` on macOS).
3. Run the start script below for your platform.
4. Open http://localhost:8069 and create a database.
5. In Odoo: Developer Mode → Apps → **Update Apps List** → **remove filter "Apps"** → search **CierTech Bikes** → Install.

## Mapping
- Local `./addons` → container `/mnt/extra-addons`
