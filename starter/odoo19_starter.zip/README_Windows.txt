Odoo 19 Starter — Windows

1) Install Docker Desktop (default).
2) Double-click: Start Odoo 19.bat
3) Open http://localhost:8069 and create a database.

Stop: Stop Odoo 19.bat
Change port if busy: 8070:8069 in docker-compose.yml
