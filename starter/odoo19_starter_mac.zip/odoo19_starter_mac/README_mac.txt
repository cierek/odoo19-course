Odoo 19 Starter (macOS)
=======================

Zalecana lokalizacja: ~/OdooCourse/odoo19_starter_mac

1) Przenieś folder w bezpieczne miejsce (NIE iCloud/OneDrive/Pulpit jeśli sprawiają problemy).
2) W Terminalu nadaj prawa wykonywania:
   chmod +x start_odoo19_mac.command reset_db_mac.command
3) Uruchom:
   - reset_db_mac.command  → czysta instalacja (czyści wolumeny)
   - start_odoo19_mac.command → zwykły start
4) Wejdź na: http://localhost:8069
5) Tryb dev → Apps → Update Apps List → zainstaluj "CierTech Bikes".

Rozwiązywanie problemów:
- Jeżeli moduł nie jest widoczny, sprawdź czy katalog "addons/cier_bikes" istnieje i czy "docker-compose.yml" montuje "./addons" do "/mnt/extra-addons".
- Jeżeli port 8069 zajęty: zamknij inne instancje Odoo; użyj "docker compose down".