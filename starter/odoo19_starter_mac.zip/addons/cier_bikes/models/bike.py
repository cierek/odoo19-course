from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class CierBike(models.Model):
    _name = "cier.bike"
    _description = "CierTech Bikes"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(required=True, tracking=True)
    frame_no = fields.Char(string="Frame No.", required=True, index=True)
    purchase_date = fields.Date()
    warranty_months = fields.Integer(default=24)
    warranty_end = fields.Date(compute="_compute_warranty_end", store=True)

    @api.depends("purchase_date", "warranty_months")
    def _compute_warranty_end(self):
        for r in self:
            if r.purchase_date and r.warranty_months:
                r.warranty_end = fields.Date.add(r.purchase_date, months=r.warranty_months)
            else:
                r.warranty_end = False

    @api.constrains("frame_no")
    def _check_frame_unique(self):
        for r in self:
            if r.frame_no and self.search_count([("frame_no", "=", r.frame_no), ("id", "!=", r.id)]):
                raise ValidationError(_("Frame number must be unique."))
