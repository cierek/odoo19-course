{
    'name': 'CierTech Bikes',
    'version': '19.0.1.0.0',
    'summary': 'Sample module for the course',
    'license': 'LGPL-3',
    'author': 'Piotr Cierkosz',
    'website': 'https://github.com/cierek/odoo19-course',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/bike_views.xml',
    ],
    'application': True,
    'installable': True,
}
