Odoo 19 Starter — macOS

1) Install Docker Desktop (Apple/Intel).
2) First time: chmod +x "Start Odoo 19.command" "Stop Odoo 19.command"
3) Double-click Start Odoo 19.command → http://localhost:8069 → create DB.
